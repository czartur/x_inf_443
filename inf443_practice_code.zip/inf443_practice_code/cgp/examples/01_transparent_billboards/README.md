# Transparent billboards

This code uses a shader to display partly transparent textures. The code illustrates this use to display complex foliage of a pine tree.

<img src="pic.jpg" alt="" width="500px"/>