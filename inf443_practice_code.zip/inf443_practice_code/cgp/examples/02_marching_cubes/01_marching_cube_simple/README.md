# Marching Cube (simple)

Example of simple marching cube applied to an arbitrary function (a blobby function here) within a fixed domain.

<img src="pic.jpg" alt="" width="500px"/>