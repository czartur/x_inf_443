# Shader deformation

This code shows a procedural deformation fully computed in the vertex shader. A regular flat grid is displayed at each frame, and a deformation is applied in the vertex shader based on a time variable.

<img src="pic.jpg" alt="" width="500px"/>