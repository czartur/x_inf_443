#pragma once


namespace cgp_test
{
	void test_numarray();
}

