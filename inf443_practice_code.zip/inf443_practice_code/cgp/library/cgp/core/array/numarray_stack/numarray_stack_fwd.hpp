#pragma once

namespace cgp
{
	template <typename T, int N> struct buffer_stack;
}