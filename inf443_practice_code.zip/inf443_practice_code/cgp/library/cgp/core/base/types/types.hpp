#pragma once

#include <array>

#include "../stl/stl.hpp"

namespace cgp
{
	///** Stores 2-int {a,b,c}. */
	//using int2 = std::array<int, 2>;
	///** Stores 3-int {a,b,c}. */
	//using int3 = std::array<int, 3>;

	//
	///** Stores 2-index {a,b}.*/
	//using size_t2 = std::array<size_t,2>;
	///** Stores 3-index {a,b,c}.*/
	//using size_t3 = std::array<size_t,3>;

	///** Stores 3-unsigned int {a,b,c}.
	// * use for triangle connectivity in OpenGL. */
	//using uint3  = std::array<unsigned int, 3>;


	///** Stores 2-float {a,b}. */
	//using float2 = std::array<float, 2>;
	///** Stores 3-float {a,b,c}. */
	//using float3 = std::array<float, 3>;
}

