#pragma once

namespace cgp_test
{
	void test_grid_2D();
	void test_grid_3D();
}
