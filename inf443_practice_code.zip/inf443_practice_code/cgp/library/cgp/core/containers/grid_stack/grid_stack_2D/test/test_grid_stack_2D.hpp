#pragma once 

namespace cgp_test
{
	void test_grid_stack_2D();
}

