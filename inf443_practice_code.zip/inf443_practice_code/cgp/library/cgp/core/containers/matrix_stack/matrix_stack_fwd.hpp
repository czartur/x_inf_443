#pragma once

namespace cgp {
	template <typename T, int N1, int N2> struct matrix_stack;
}