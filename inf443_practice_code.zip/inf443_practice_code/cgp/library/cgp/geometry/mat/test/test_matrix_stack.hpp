#pragma once 

namespace cgp_test
{
	void test_matrix_stack();
}

