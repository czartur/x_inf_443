#pragma once

#include "marching_cube/marching_cube.hpp"