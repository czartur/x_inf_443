#include "environment.hpp"


namespace cgp
{
	void environment_generic_structure::send_opengl_uniform(opengl_shader_structure const&, bool) const
	{
	}


}