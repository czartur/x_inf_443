#pragma once

#include "material_mesh_drawable_phong/material_mesh_drawable_phong.hpp"