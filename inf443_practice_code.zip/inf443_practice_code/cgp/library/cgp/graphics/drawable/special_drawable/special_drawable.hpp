#pragma once

// Custom drawable structures to ease specific type of elements
#include "skybox_drawable/skybox_drawable.hpp"
#include "trajectory_drawable/trajectory_drawable.hpp"