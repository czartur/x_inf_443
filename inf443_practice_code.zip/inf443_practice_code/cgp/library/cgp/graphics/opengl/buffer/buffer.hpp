#pragma once

#include "opengl_buffer/opengl_buffer.hpp"
#include "vbo/vbo.hpp"
#include "ebo/ebo.hpp"