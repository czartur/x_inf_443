#include "picking_structure.hpp"

namespace cgp
{
	picking_structure::picking_structure()
		:active(false), index(-1), position(), normal(), ray_origin(), ray_direction(), screen_clicked()
	{

	}
}