#include <iostream>
#include <cmath>

int main()
{
    std::cout << "Hello world" << std::endl;

    return 0;
}
