#pragma once


#include "cgp/cgp.hpp"


cgp::mesh disc_with_texture();
cgp::mesh cylinder_with_texture();
cgp::mesh torus_with_texture();
