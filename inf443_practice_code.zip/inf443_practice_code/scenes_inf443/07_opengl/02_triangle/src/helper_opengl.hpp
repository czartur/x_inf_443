
#include "../third_party/src/glad/include/glad/glad.hpp"

#include <iostream>


GLuint opengl_load_shader(std::string const& vertex_shader_path, std::string const& fragment_shader_path);